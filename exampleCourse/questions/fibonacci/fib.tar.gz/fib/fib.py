def fib(n):
    # your code goes here

def main():
    print("The 20th Fibonacci number is %d" % fib(20))

if __name__ == '__main__':
    main()
