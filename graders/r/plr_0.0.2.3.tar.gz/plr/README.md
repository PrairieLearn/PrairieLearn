## plr

### What is it?

Helper functions for [PrairieLearn](https://github.com/PrairieLearn/PrairieLearn) and R as used by
[STAT430](https://stat430.com) (during 2018-2020) and now [STAT447](https://stat447.com).

### Who wrote it?

Dirk Eddelbuettel and Alton Barbehenn

### Thanks to

Jeroen Ooms for the excellent [unix](https://github.com/jeroen/unix) package, and of course the
whole [PrairieLearn](https://github.com/PrairieLearn/PrairieLearn) team for their system
