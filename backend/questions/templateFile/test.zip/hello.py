def main():
    # Your code goes here

if __name__ == '__main__':
    main()
